module.exports=[94731,(e,o,d)=>{}];

//# sourceMappingURL=0jwu_odpco-website__next-internal_server_app_sitemap_xml_route_actions_0oqovou.js.map