module.exports=[20228,(e,o,d)=>{}];

//# sourceMappingURL=1tgq__next-internal_server_app_api_auth_%5B___nextauth%5D_route_actions_154qj-m.js.map