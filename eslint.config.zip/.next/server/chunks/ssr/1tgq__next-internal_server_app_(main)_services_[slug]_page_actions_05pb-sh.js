module.exports=[72389,a=>{"use strict";var b=a.i(7653);a.s([],14852),a.i(14852),a.s(["806336f21e94945a48baebb4773312fd321bd96a1e",()=>b.$$RSC_SERVER_CACHE_0],72389)}];

//# sourceMappingURL=1tgq__next-internal_server_app_%28main%29_services_%5Bslug%5D_page_actions_05pb-sh.js.map