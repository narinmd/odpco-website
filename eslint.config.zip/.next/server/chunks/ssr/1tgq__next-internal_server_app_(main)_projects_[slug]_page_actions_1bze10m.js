module.exports=[64311,a=>{"use strict";var b=a.i(7653);a.s([],11650),a.i(11650),a.s(["806336f21e94945a48baebb4773312fd321bd96a1e",()=>b.$$RSC_SERVER_CACHE_0],64311)}];

//# sourceMappingURL=1tgq__next-internal_server_app_%28main%29_projects_%5Bslug%5D_page_actions_1bze10m.js.map