module.exports=[56664,a=>{"use strict";var b=a.i(7653);a.s([],9954),a.i(9954),a.s(["806336f21e94945a48baebb4773312fd321bd96a1e",()=>b.$$RSC_SERVER_CACHE_0],56664)}];

//# sourceMappingURL=0jwu_odpco-website__next-internal_server_app_%28main%29_projects_page_actions_0pctzr_.js.map