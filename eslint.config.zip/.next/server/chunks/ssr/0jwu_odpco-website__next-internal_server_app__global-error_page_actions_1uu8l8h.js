module.exports=[14349,(a,b,c)=>{}];

//# sourceMappingURL=0jwu_odpco-website__next-internal_server_app__global-error_page_actions_1uu8l8h.js.map