module.exports=[44850,(a,b,c)=>{}];

//# sourceMappingURL=0jwu_odpco-website__next-internal_server_app_%28admin%29_dashboard_page_actions_1sgxlay.js.map