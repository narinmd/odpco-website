module.exports=[78923,(e,o,d)=>{}];

//# sourceMappingURL=0jwu_odpco-website__next-internal_server_app_robots_txt_route_actions_1o4sngz.js.map