1:"$Sreact.fragment"
2:I[44991,["/_next/static/chunks/2n-9fxllznz9u.js","/_next/static/chunks/2h6b7z_she7tg.js"],"ClientPageRoot"]
3:I[11659,["/_next/static/chunks/2n-9fxllznz9u.js","/_next/static/chunks/2h6b7z_she7tg.js","/_next/static/chunks/35hl71rgpbvo3.js"],"default"]
4:I[48777,["/_next/static/chunks/2n-9fxllznz9u.js","/_next/static/chunks/2h6b7z_she7tg.js"],"OutletBoundary"]
5:"$Sreact.suspense"
7:[]
0:{"rsc":["$","$1","c",{"children":[["$","$L2",null,{"Component":"$3","serverProvidedParams":null}],[["$","script","script-0",{"src":"/_next/static/chunks/35hl71rgpbvo3.js","async":true}]],["$","$L4",null,{"children":["$","$5",null,{"name":"Next.MetadataOutlet","children":"$@6"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W7","buildId":"s8V6F_GzA9sHv7X8XwXj8"}
6:null
