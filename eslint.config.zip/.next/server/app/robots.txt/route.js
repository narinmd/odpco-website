var R=require("../../chunks/[turbopack]_runtime.js")("server/app/robots.txt/route.js")
R.c("server/chunks/[root-of-the-server]__042yjp8._.js")
R.c("server/chunks/[root-of-the-server]__0o-3iwp._.js")
R.c("server/chunks/0dn2_next_02zdsdi._.js")
R.c("server/chunks/0jwu_odpco-website__next-internal_server_app_robots_txt_route_actions_1o4sngz.js")
R.m(71125)
module.exports=R.m(71125).exports
