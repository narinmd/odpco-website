1:"$Sreact.fragment"
3:I[48777,["/_next/static/chunks/2n-9fxllznz9u.js","/_next/static/chunks/2h6b7z_she7tg.js"],"OutletBoundary"]
4:"$Sreact.suspense"
6:[]
0:{"rsc":["$","$1","c",{"children":["$L2",[["$","script","script-0",{"src":"/_next/static/chunks/0z3d8r324b6in.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":true,"staleTime":300,"varyParams":"$W6","buildId":"s8V6F_GzA9sHv7X8XwXj8"}
5:null
