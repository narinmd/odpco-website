var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/[...nextauth]/route.js")
R.c("server/chunks/[externals]__0frghuo._.js")
R.c("server/chunks/0dn2_0qzrotx._.js")
R.c("server/chunks/[root-of-the-server]__0o-3iwp._.js")
R.c("server/chunks/1tgq__next-internal_server_app_api_auth_[___nextauth]_route_actions_154qj-m.js")
R.m(39741)
module.exports=R.m(39741).exports
