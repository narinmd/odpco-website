1:"$Sreact.fragment"
2:I[48777,["/_next/static/chunks/2n-9fxllznz9u.js","/_next/static/chunks/2h6b7z_she7tg.js"],"OutletBoundary"]
3:"$Sreact.suspense"
5:[]
0:{"rsc":["$","$1","c",{"children":[["$","div",null,{}],null,["$","$L2",null,{"children":["$","$3",null,{"name":"Next.MetadataOutlet","children":"$@4"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W5","buildId":"s8V6F_GzA9sHv7X8XwXj8"}
4:null
