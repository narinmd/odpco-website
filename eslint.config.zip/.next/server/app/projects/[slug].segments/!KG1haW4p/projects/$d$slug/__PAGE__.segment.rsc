1:"$Sreact.fragment"
3:I[48777,["/_next/static/chunks/2n-9fxllznz9u.js","/_next/static/chunks/2h6b7z_she7tg.js"],"OutletBoundary"]
4:"$Sreact.suspense"
:HL["/_next/static/chunks/3eo_fjyxo_ywd.css","style"]
6:[]
0:{"rsc":["$","$1","c",{"children":["$L2",[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/3eo_fjyxo_ywd.css","precedence":"next"}],["$","script","script-0",{"src":"/_next/static/chunks/0qv3ilg_s37po.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/1-fdpe_2n4wmd.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":true,"staleTime":300,"varyParams":"$W6","buildId":"s8V6F_GzA9sHv7X8XwXj8"}
