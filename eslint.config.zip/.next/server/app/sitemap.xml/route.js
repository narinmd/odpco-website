var R=require("../../chunks/[turbopack]_runtime.js")("server/app/sitemap.xml/route.js")
R.c("server/chunks/[externals]_next_dist_1ce_grm._.js")
R.c("server/chunks/0dn2_1rvdc60._.js")
R.c("server/chunks/0dn2_next_02zdsdi._.js")
R.c("server/chunks/[root-of-the-server]__0o-3iwp._.js")
R.c("server/chunks/0jwu_odpco-website__next-internal_server_app_sitemap_xml_route_actions_0oqovou.js")
R.m(97717)
module.exports=R.m(97717).exports
