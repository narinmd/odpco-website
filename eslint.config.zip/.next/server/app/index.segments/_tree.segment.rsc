:HL["/_next/static/chunks/163pqxonek7b7.css","style"]
:HL["/_next/static/chunks/0x-f7wph1hdxl.css","style"]
:HL["/_next/static/chunks/3wmodj9l-9lc3.css","style"]
:HL["/_next/static/chunks/3eo_fjyxo_ywd.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"(main)","param":null,"prefetchHints":0,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}}}},"staleTime":300,"buildId":"s8V6F_GzA9sHv7X8XwXj8"}
